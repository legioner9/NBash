/**
 * @file
 *
 * @brief b.c
 */

/**
 * @brief E in b.c
 */
enum E {
  /**
   * @brief A in b.c
   */
  A,

  /**
   * @brief B in b.c
   */
  B
};
