#ifndef MD5LOC_H
#define MD5LOC_H

# define UWORD32 unsigned int

#endif
