assert ( os.setlocale ( 'C' ), 'could not set locale' )
