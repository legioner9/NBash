-- echo command line arguments

for idx, val in ipairs ( { ... } ) do
	print ( idx, val )
end
