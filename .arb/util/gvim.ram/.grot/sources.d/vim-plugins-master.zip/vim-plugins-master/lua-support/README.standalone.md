Preface
================================================================================

This repository is mainly for the use with plug-in managers.

Have a look at the [Screenshot Page](https://wolfgangmehner.github.io/vim-plugins/luasupport.html).

The development happens in [WolfgangMehner/vim-plugins](https://github.com/WolfgangMehner/vim-plugins).


Preview Version
================================================================================

___This is a preview version!___

Notable new feature:

- Run Lua in a terminal window directly inside the editor.
- Fully enabled for Neovim.

The terminal window relies on the new `+terminal` feature, which becomes
available with a patch level of approx. `8.0.1000`.

_Please read the release notes below._


--------------------------------------------------------------------------------

