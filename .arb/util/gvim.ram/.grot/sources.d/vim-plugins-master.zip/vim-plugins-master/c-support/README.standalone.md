Preface
================================================================================

This repository is mainly for the use with plug-in managers.

Have a look at the [Screenshot Page](https://wolfgangmehner.github.io/vim-plugins/csupport.html).

The development happens in [WolfgangMehner/vim-plugins](https://github.com/WolfgangMehner/vim-plugins).


--------------------------------------------------------------------------------

