---
name: Typo / grammatical error / spelling mistakes etc.
about: Report a grammatical error or a typo in the tutorial
title: "[TYPO]"
labels: typo
assignees: prakhar1989

---

For typos, grammatical errors etc, a pull-request would be awesome! Just edit [this file](https://github.com/prakhar1989/docker-curriculum/blob/master/tutorial/src/index.md) with the suggested changes and I'll review it asap.

If for some reason, you are unable to send a pull-request, just paste the error and the correction. Thank you =)

### Error

### Correction
