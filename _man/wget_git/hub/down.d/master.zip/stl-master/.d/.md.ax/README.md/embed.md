# <embed> Развертывание

[up to parent doc](../../../README.md)

```bash
cd "${PLT_PATH}"
git clone 
```

[up to README.md](../../../README.md)