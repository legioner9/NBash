#!/bin/bash

colors_const_stl() { # $1 str question
    #? ALIASE_OLD
    NORMAL='\033[0m'
    HLIGHT='\033[1m'
    LLIGHT='\033[2m'

    BLACK='\033[0;30m'
    RED='\033[0;31m'
    GREEN='\033[0;32m'
    YELLOW='\033[0;33m'
    BLUE='\033[0;34m'
    MAGENTA='\033[0;35m'
    CYAN='\033[0;36m'
    GRAY='\033[0;37m'

    return 0
}

colors_const_stl
