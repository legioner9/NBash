#!/bin/bash

pth_to_lib_boot_stl_const(){

export STL_PATH=${HOME}/REPOBARE/_repo/stl/stl.lib.d
export STL_DATA_PATH=${HOME}/REPOBARE/_repo/stl/stl.data.d

export STL1_PATH=${HOME}/REPOBARE/_repo/stl/stl1.lib.d
export STL1_DATA_PATH=${HOME}/REPOBARE/_repo/stl1_data_st/stl1.data.d

}

pth_to_lib_boot_stl_const
