#!/bin/bash

if commandX ; then
    plt_info "in file://XXX/xxx : TRUE_EXEC : commandX : return 1"
    return 1
fi