#

## \<OPUS_PATH>=$(dirname cntx.res.md) корневая opus dr

## \<OPUS_PATH>/.ins_dr dr with inner sd_opus gig ufl_stl0_9

sd_opus - opus лежащая в поддиректориях - в нашем случае в \<OPUS_PATH>/.ins_dr/\<name_opus>
itterator [список \<name_opus>] - одномерный иттератор

## \<OPUS_PATH>/.d/.lst/out_opus_lst_arb.lst list path to outer .arb with arb_opus gig ufl_stl0_11

arb_opus - opus лежащая в \<root>/.arb/\<name_arb>/\<name_ram>.ram/.grot/opus.d/\<name_opus>
itterator [список \<name_arb>  [список \<name_ram> [список \<name_opus>] ] ] - трехмерный иттератор