#!/bin/bash

ufl_stl0_9_glar_force=-force 
ufl_stl0 9 \
${REPO_PATH}/stl/.d/.stl.d.copy/data.d/opus.d/boot.opus/cntx.ins.d \
${REPO_PATH}/stl/.d/.opus/readme.opus/cntx.ins.d/099.from_dot_stl.d.ax/001.from_dot_stl.file.md \
2
ufl_stl0_9_glar_force= 
