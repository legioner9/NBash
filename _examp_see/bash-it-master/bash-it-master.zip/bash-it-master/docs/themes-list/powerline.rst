.. _powerline:

Powerline Theme
===============

A colorful theme, where shows a lot information about your shell session.

See :ref:`powerline_base` for general information about the powerline theme.

Soft Separators
^^^^^^^^^^^^^^^

Adjacent segments having the same background color will use a less-pronouced (i.e. soft) separator between them.
