_log_warning 'Bash completion for "crystal" is now covered by "system". This completion can be disabled.'
