_log_warning 'Bash completion for "virsh" is now deprecated, as it used code with incompatible license.
Please disable this completion and use the instructions from "virsh" developers instead.'
