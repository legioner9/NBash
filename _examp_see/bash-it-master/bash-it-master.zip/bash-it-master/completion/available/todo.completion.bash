_log_warning 'Bash completion for "todo.txt-cli" is now deprecated, as it used code with incompatible license.
Please disable this completion and use the instructions from "todo.txt-cli" developers instead.'
