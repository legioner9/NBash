# shellcheck shell=bash
about-completion "jboss7 completion"
# shellcheck disable=SC1090
source "${BASH_IT}"/vendor/github.com/rparree/jboss-bash-completion/jboss7
