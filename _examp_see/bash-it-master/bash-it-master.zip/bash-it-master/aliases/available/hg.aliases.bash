# shellcheck shell=bash
about-alias 'mercurial abbreviations'

alias hs='hg status'
alias hsum='hg summary'
alias hcm='hg commit -m'
