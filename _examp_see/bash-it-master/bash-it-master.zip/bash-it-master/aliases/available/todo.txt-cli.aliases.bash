# shellcheck shell=bash
about-alias 'todo.txt-cli abbreviations'

alias tls='"${TODO?}" ls'
alias ta='"${TODO?}" a'
alias trm='"${TODO?}" rm'
alias tdo='"${TODO?}" do'
alias tpri='"${TODO?}" pri'
